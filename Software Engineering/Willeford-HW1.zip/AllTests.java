// The TestRunner for the JUnit Tests for both the Logic and GUI.
// Consolidates the different test classes and their test cases and runs them together.
// For more specific information on the individual tests/modules please refer to the documentation located
// within the relevant files: FiveModelTest.java,FiveTest.java
import junit.framework.*;
import junit.runner.BaseTestRunner;

public class AllTests {
	private static TestSuite suite;
	public static Test suite() {
		suite= new TestSuite("tests");
		// Add FiveTest's Test Cases
		suite.addTestSuite(FiveTest.class);
		// Add FiveModel's Test Cases
		suite.addTestSuite(FiveModelTest.class);
		return suite;
	}
	public static void main(String[] args) {
		// Run Tests
		junit.textui.TestRunner.run(suite());
	}
}