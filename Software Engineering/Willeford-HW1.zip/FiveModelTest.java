// Contained within this file are Unit Tests for the Logic Portion of the Five Program.
// Above each test case will be a bit of information summarizing the purpose of the test.
import junit.framework.*;

public class FiveModelTest extends TestCase {
	public FiveModelTest(){}
	protected void setUp(){}
	protected void tearDown(){}
	// testConstructorResetMoveLoopn all together cover each of the types of coverage for the functions 
	// FiveModelTest, Reset, and Move. (With the exception of one edge case.)
	public void testConstructorResetMoveLoop1(){
		// First Loop Accessed Zero Times, Second Loop Never Accessed
		// Out of Bounds Error in Move
		new FiveModel(0,0);
	}
	public void testConstructorResetMoveLoop2(){
		// First Loop Accessed Once, Second Loop Accessed Zero Times
		// Out of Bounds Error in Move
		new FiveModel(1,0);
	}
	public void testConstructorResetMoveLoop3(){
		// First Loop Accessed Many, Second Loop Accessed Once
		// Out of Bounds Error in Move
		new FiveModel(2,1);		
	}
	public void testConstructorResetMoveLoop4(){
		// Second Loop Executes Many Times
		// Out of Bounds Error in Move, Does not Seem to Occur in (>1,>1) case.
		// So any test cases that depend on <=1 for rows or columns are infeasible.
		new FiveModel(1,2);
	}
	// Covers the edge case where Move is executed on a non-empty spot.
	public void testMoveEdgeCase(){
		FiveModel t = new FiveModel(2,2);
		t.move(0,0);
	}
	// Trivial Tests, These Two Are Executed for Statement Coverage.
	public void testGetPlayerAtTrivial(){
		FiveModel t = new FiveModel(2,2);
		Assert.assertEquals(t.getPlayerAt(0,0),0);
	}
	public void testGetNextPlayerTrivial(){
		FiveModel t = new FiveModel(2,2);		
		Assert.assertEquals(t.getNextPlayer(),2);
	}
	// Only Many Many Loop Path is Actually Feasible
	public void testGetGameStatusWinUp(){
		// Checks for Win Up
		// Spoof Game
		FiveModel t = new FiveModel(5,5);
		// Adversary, (remember that first move is forced, center of board)
		// This will be the case in the other tests as well.
		t.move(3,2);
		// Main
		t.move(2,1);
		// ...
		t.move(3,1);
		t.move(2,0);
		t.move(3,0);
		t.move(2,3);
		t.move(3,3);
		t.move(2,4);
		// Get Result, Player One Should Win
		Assert.assertEquals(t.getGameStatus(),1);
	}
	public void testGetGameStatusWinRight(){
		// Checks for Win Right
		// Spoof Game
		FiveModel t = new FiveModel(5,5);
		t.move(2,1);
		t.move(3,2);
		t.move(3,1);
		t.move(4,2);
		t.move(4,1);
		t.move(1,2);
		t.move(1,1);
		t.move(0,2);
		// Get Result, Player One Should Win
		Assert.assertEquals(t.getGameStatus(),1);
	}
	public void testGetGameStatusWinDiagonalUpRight(){
		// Checks for Win Diagonal Up Right
		// Spoof Game
		FiveModel t = new FiveModel(5,5);
		t.move(3,2);
		t.move(3,3);
		t.move(4,3);
		t.move(4,4);
		t.move(2,1);
		t.move(1,1);
		t.move(1,0);
		t.move(0,0);
		// Get Result, Player One Should Win
		Assert.assertEquals(t.getGameStatus(),1);
	}
	public void testGetGameStatusWinDiagonalUpLeft(){
		// Checks for Win Diagonal Up Left
		// Spoof Game
		FiveModel t = new FiveModel(5,5);
		t.move(3,2);
		t.move(3,1);
		t.move(4,1);
		t.move(4,0);
		t.move(2,3);
		t.move(1,3);
		t.move(1,4);
		t.move(0,4);
		// Get Result, Player One Should Win
		Assert.assertEquals(t.getGameStatus(),1);
	}
	public void testGetGameStatusNoWinDiagonalUpLeftTie(){
		// Checks for No Win Diagonal Up Left, Tie
		// Spoof Game
		FiveModel t = new FiveModel(5,5);
		t.move(3,2);
		t.move(3,1);
		t.move(4,1);
		t.move(4,0);
		t.move(2,3);
		t.move(1,3);
		t.move(1,4);
		t.move(3,3);
		t.move(0,4);
		t.move(4,4);
		t.move(2,1);
		t.move(1,1);
		t.move(0,0);
		t.move(0,2);
		t.move(3,0);
		t.move(1,0);
		t.move(2,0);
		t.move(4,2);
		t.move(1,2);
		t.move(0,3);
		t.move(0,1);
		t.move(2,4);
		t.move(3,4);
		t.move(4,3);
		// Get Result, Should be Tie
		Assert.assertEquals(t.getGameStatus(),-1);
	}
	public void testGetGameStatusNoWinDiagonalUpLeftNoTie(){
		// Checks for No Win Diagonal Up Left, No Tie
		// Spoof Game, no moves works here.
		FiveModel t = new FiveModel(5,5);
		// Get Result, Game Should Still be Going
		Assert.assertEquals(t.getGameStatus(),0);
	}
}
