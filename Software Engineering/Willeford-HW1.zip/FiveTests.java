// Contained within this file are Unit Tests for the GUI Portion of the Five Program.
// Atleast it would if I could get Sikuli to work. 
import junit.framework.*;

public class FiveTest extends TestCase {
	public FiveTest(){}
	protected void setUp(){}
	protected void tearDown(){}
	public void test1(){}
}
